package edu.uncc.inclass08;

public class Grade {
}
